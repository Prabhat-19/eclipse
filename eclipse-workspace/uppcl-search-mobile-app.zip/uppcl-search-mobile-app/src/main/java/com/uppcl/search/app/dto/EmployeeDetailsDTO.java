package com.uppcl.search.app.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Data
public class EmployeeDetailsDTO {
	private String firstName;
	private String lastName;
	private String post;
	private String path;
		


}
