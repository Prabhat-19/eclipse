package com.uppcl.search.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UppclSearchMobileAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(UppclSearchMobileAppApplication.class, args);
	}

}
