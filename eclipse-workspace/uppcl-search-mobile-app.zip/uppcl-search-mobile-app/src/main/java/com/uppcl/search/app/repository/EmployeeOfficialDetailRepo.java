package com.uppcl.search.app.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.uppcl.search.app.domain.EmployeeOfficalDetail;

public interface EmployeeOfficialDetailRepo extends JpaRepository<EmployeeOfficalDetail, Long> {

}
