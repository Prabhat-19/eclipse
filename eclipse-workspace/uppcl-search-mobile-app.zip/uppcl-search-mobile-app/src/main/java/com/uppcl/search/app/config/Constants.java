package com.uppcl.search.app.config;

public class Constants {
	
	public static final String API_URL = "http://localhost:4200";
	    private Constants() {
	    } 
	  
	  

}
