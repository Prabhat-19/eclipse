package com.uppcl.search.app.dto;

public class MobileNumberDTO {
	
	private String checkMobileNumber;

	public String getCheckMobileNumber() {
		return checkMobileNumber;
	}

	public void setCheckMobileNumber(String checkMobileNumber) {
		this.checkMobileNumber = checkMobileNumber;
	}

	
	

}
