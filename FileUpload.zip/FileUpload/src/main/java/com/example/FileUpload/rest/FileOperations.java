package com.example.FileUpload.rest;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.example.FileUpload.Conig.Application;
import com.example.FileUpload.Service.FileOperationsService;

import springfox.documentation.swagger2.annotations.EnableSwagger2;


@RestController
@RequestMapping("/api")
public class FileOperations {
	
	private final FileOperationsService fileUploadService;
	private final Application applicationProp;
	
	public FileOperations(FileOperationsService fileUploadService, Application applicationProp) {
		super();
		this.fileUploadService = fileUploadService;
		this.applicationProp = applicationProp;
	}


	@GetMapping("/upload")
	public ModelAndView showUpload() {
		return new ModelAndView("fileUpload");
		
	}
	
	
	@PostMapping("/fileupload")
    public ResponseEntity<String> DocumentUpload(@Valid @NotNull @NotBlank @NotEmpty @RequestBody MultipartFile file) {
     String string = fileUploadService.uploadDocument(file);
        return ResponseEntity.ok(string);
    } 
	
	@GetMapping("/getProp")
	public String getProp()
	{
		return applicationProp.getEmail();
	}

}
