package com.example.FileUpload.ServiceImpl;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.FileUpload.Service.FileOperationsService;


@Service
public class FileOperationServiceImpl implements FileOperationsService {


	@Override
	public String uploadDocument(@Valid MultipartFile file) {
		
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		
		Path fileStorageLocation = Paths.get("/Users/prabhat/uploadFile/").toAbsolutePath().normalize();
		File directory=new File("/Users/prabhat/uploadFile");
		if(directory.exists())
		{
			
			
				try {
					Path targetLocation  = fileStorageLocation.resolve(fileName);
					Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
					
					
				} catch (IOException e) {
					
					e.printStackTrace();
				}
				return fileStorageLocation.toString().concat("/").concat(fileName);
				
			
		}
		
		else
		{			try {
				Files.createDirectories(fileStorageLocation);
				Path targetLocation  = fileStorageLocation.resolve(fileName);
				Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return fileStorageLocation.toString().concat("/").concat(fileName);
		}
		
		
	}

}
