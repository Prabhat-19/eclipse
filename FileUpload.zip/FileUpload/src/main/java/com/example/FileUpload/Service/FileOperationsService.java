package com.example.FileUpload.Service;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import org.springframework.web.multipart.MultipartFile;

public interface FileOperationsService {
	
	String uploadDocument(@Valid @NotBlank @NotEmpty MultipartFile file);
	
	

}
